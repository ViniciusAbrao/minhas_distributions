from setuptools import setup

setup(name='minhas_distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['minhas_distributions'],
      zip_safe=False)
